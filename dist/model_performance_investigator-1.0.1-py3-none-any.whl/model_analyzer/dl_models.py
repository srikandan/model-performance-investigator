
def df_print():
    print('Hai DL')